export interface PresetStyle {
  id: string;
  name: string;
  description: string;
  previewColor: string;
}

export interface ImageFile {
  file: File;
  previewUrl: string;
  base64: string;
  mimeType: string;
}

export type GenerationStatus = 'idle' | 'generating' | 'success' | 'error';
